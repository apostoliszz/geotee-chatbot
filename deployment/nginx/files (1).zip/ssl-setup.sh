#!/bin/bash

# SSL Setup Script για ai-geotee.cloud
# Αυτοματοποιεί την εγκατάσταση Let's Encrypt certificate

set -e

DOMAIN="ai-geotee.cloud"
EMAIL="your-email@example.com"  # ⚠️ ΑΛΛΑΞΕ ΑΥΤΟ!
PROJECT_DIR="/opt/geotee-chatbot"
SSL_DIR="$PROJECT_DIR/deployment/ssl"

echo "🔐 Let's Encrypt SSL Setup για $DOMAIN"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# Check if running as root
if [ "$EUID" -ne 0 ]; then 
    echo "❌ Παρακαλώ τρέξε το script ως root (sudo)"
    exit 1
fi

# Check email
if [ "$EMAIL" = "your-email@example.com" ]; then
    echo "⚠️  ΠΡΟΣΟΧΗ: Πρέπει να αλλάξεις το EMAIL στο script!"
    echo ""
    read -p "Δώσε το email σου: " EMAIL
    if [ -z "$EMAIL" ]; then
        echo "❌ Το email είναι υποχρεωτικό!"
        exit 1
    fi
fi

echo "📧 Email: $EMAIL"
echo "🌐 Domain: $DOMAIN"
echo ""

# Check if certbot is installed
if ! command -v certbot &> /dev/null; then
    echo "📦 Εγκατάσταση Certbot..."
    dnf install -y certbot python3-certbot-nginx || yum install -y certbot python3-certbot-nginx
fi

# Create SSL directory
echo "📁 Δημιουργία SSL directory..."
mkdir -p "$SSL_DIR"

# Stop nginx container
echo "⏸️  Σταμάτημα Nginx container..."
cd "$PROJECT_DIR/deployment/docker"
docker-compose stop nginx 2>/dev/null || true

# Wait for port to be released
sleep 3

# Request certificate
echo ""
echo "🔐 Αίτηση SSL Certificate από Let's Encrypt..."
echo "   (Αυτό μπορεί να πάρει 1-2 λεπτά)"
echo ""

certbot certonly --standalone \
    -d "$DOMAIN" \
    --email "$EMAIL" \
    --agree-tos \
    --no-eff-email \
    --preferred-challenges http \
    --non-interactive

# Check if certificate was created
if [ ! -f "/etc/letsencrypt/live/$DOMAIN/fullchain.pem" ]; then
    echo ""
    echo "❌ ΣΦΑΛΜΑ: Το certificate δεν δημιουργήθηκε!"
    echo ""
    echo "💡 Πιθανές αιτίες:"
    echo "   1. Το DNS δεν έχει γίνει propagate ακόμα"
    echo "   2. Το port 80 δεν είναι προσβάσιμο από το internet"
    echo "   3. Firewall blocking"
    echo ""
    echo "🔍 Έλεγχος:"
    echo "   • Τρέξε: ./check-dns.sh"
    echo "   • Τρέξε: firewall-cmd --list-all"
    echo "   • Βεβαιώσου ότι το port 80 είναι ανοιχτό"
    echo ""
    
    # Restart nginx anyway
    docker-compose up -d nginx
    exit 1
fi

echo ""
echo "✅ Certificate δημιουργήθηκε επιτυχώς!"
echo ""

# Copy certificates to project directory
echo "📋 Αντιγραφή certificates..."
cp /etc/letsencrypt/live/$DOMAIN/fullchain.pem "$SSL_DIR/"
cp /etc/letsencrypt/live/$DOMAIN/privkey.pem "$SSL_DIR/"
chmod 644 "$SSL_DIR"/*.pem

echo "✅ Certificates αντιγράφηκαν στο: $SSL_DIR"
echo ""

# Start nginx
echo "🚀 Εκκίνηση Nginx με SSL..."
docker-compose up -d nginx

# Wait for nginx to start
sleep 5

# Test HTTPS
echo ""
echo "🧪 Έλεγχος HTTPS..."
if curl -k -I -s https://$DOMAIN/health | grep -q "200"; then
    echo "✅ HTTPS λειτουργεί!"
else
    echo "⚠️  HTTPS δεν απαντάει ακόμα (μπορεί να χρειαστεί λίγος χρόνος)"
fi

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "🎉 SSL Setup ολοκληρώθηκε!"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "📋 Certificate Info:"
certbot certificates -d $DOMAIN
echo ""

# Setup auto-renewal
echo "⏰ Ρύθμιση auto-renewal..."

# Create renewal script
cat > /opt/geotee-chatbot/ssl-renew.sh << 'EOF'
#!/bin/bash
certbot renew --quiet
cp /etc/letsencrypt/live/ai-geotee.cloud/*.pem /opt/geotee-chatbot/deployment/ssl/
docker-compose -f /opt/geotee-chatbot/deployment/docker/docker-compose.yml restart nginx
EOF

chmod +x /opt/geotee-chatbot/ssl-renew.sh

# Add to crontab
(crontab -l 2>/dev/null | grep -v ssl-renew.sh; echo "0 3 * * * /opt/geotee-chatbot/ssl-renew.sh >> /opt/geotee-chatbot/logs/ssl-renew.log 2>&1") | crontab -

echo "✅ Auto-renewal ρυθμίστηκε (κάθε μέρα στις 3:00 π.μ.)"
echo ""

echo "📍 Το chatbot είναι τώρα διαθέσιμο στο:"
echo ""
echo "   🌐 https://$DOMAIN"
echo "   📊 https://$DOMAIN/analytics"
echo "   🔌 https://$DOMAIN/webhooks/rest/webhook"
echo ""

echo "🧪 Για testing:"
echo ""
echo "   curl https://$DOMAIN/health"
echo "   curl -X POST https://$DOMAIN/webhooks/rest/webhook \\"
echo "     -H 'Content-Type: application/json' \\"
echo "     -d '{\"sender\": \"test\", \"message\": \"γεια σου\"}'"
echo ""

echo "📚 Για περισσότερες πληροφορίες:"
echo "   cat DNS_SSL_SETUP_GUIDE.md"
echo ""

exit 0
