# 🌐 DNS & SSL Setup Guide για ai-geotee.cloud

## 📋 Περιεχόμενα
1. [DNS Check & Configuration](#dns-check)
2. [Let's Encrypt SSL Setup](#ssl-setup)
3. [Nginx Configuration Steps](#nginx-steps)
4. [Testing & Verification](#testing)

---

## 🔍 DNS Check & Configuration {#dns-check}

### Βήμα 1: Έλεγχος Τρέχοντος DNS

Τρέξε αυτή την εντολή από το **local σου μηχάνημα** (όχι στον VPS):

```bash
nslookup ai-geotee.cloud
```

**Αποτέλεσμα που ΘΕΛΟΥΜΕ να δούμε:**
```
Server:     8.8.8.8
Address:    8.8.8.8#53

Non-authoritative answer:
Name:   ai-geotee.cloud
Address: 72.61.179.204
```

**Αν δεις αυτό, το DNS είναι OK! ✅**

---

### Βήμα 2: Αν το DNS ΔΕΝ είναι ρυθμισμένο

#### 🔹 Για Hostinger Domain:

1. Πήγαινε στο **hPanel** → **Domains**
2. Βρες το domain **ai-geotee.cloud**
3. Κλικ **Manage** → **DNS / Name Servers**
4. Πρόσθεσε/Επεξεργάσου το **A Record**:

```
Type: A
Name: @ (ή κενό, ή ai-geotee)
Points to: 72.61.179.204
TTL: 3600
```

5. Αφαίρεσε τυχόν **AAAA records** (IPv6) αν υπάρχουν
6. Κάνε **Save Changes**

#### ⏱️ Propagation Time:
- Τοπικά: 5-10 λεπτά
- Παγκοσμίως: έως 24 ώρες (συνήθως 2-4 ώρες)

#### 🧪 Online DNS Check Tools:
```
https://dnschecker.org/
https://www.whatsmydns.net/
```

Έλεγξε αν το **ai-geotee.cloud** δείχνει στο **72.61.179.204**

---

## 🔐 Let's Encrypt SSL Setup {#ssl-setup}

### Προετοιμασία VPS (Μόνο 1 φορά)

```bash
# Σύνδεση στον VPS
ssh root@72.61.179.204

# Εγκατάσταση Certbot
sudo dnf install -y certbot python3-certbot-nginx

# Δημιουργία φακέλου για SSL
sudo mkdir -p /opt/geotee-chatbot/deployment/ssl
```

---

### Μέθοδος 1: Standalone (Προτεινόμενη για πρώτη φορά)

**Βήμα 1: Stop το Nginx** (αν τρέχει)
```bash
cd /opt/geotee-chatbot/deployment/docker
docker-compose stop nginx
```

**Βήμα 2: Δημιουργία SSL Certificate**
```bash
sudo certbot certonly --standalone \
  -d ai-geotee.cloud \
  --email your-email@example.com \
  --agree-tos \
  --no-eff-email \
  --preferred-challenges http
```

**Αντικατέστησε**: `your-email@example.com` με το email σου!

**Βήμα 3: Αντιγραφή Certificates στον project φάκελο**
```bash
sudo cp /etc/letsencrypt/live/ai-geotee.cloud/fullchain.pem \
       /opt/geotee-chatbot/deployment/ssl/

sudo cp /etc/letsencrypt/live/ai-geotee.cloud/privkey.pem \
       /opt/geotee-chatbot/deployment/ssl/

sudo chmod 644 /opt/geotee-chatbot/deployment/ssl/*.pem
```

**Βήμα 4: Restart Nginx**
```bash
docker-compose up -d nginx
```

---

### Μέθοδος 2: Webroot (Αν το Nginx τρέχει ήδη)

**Βήμα 1: Δημιουργία webroot folder**
```bash
sudo mkdir -p /var/www/certbot
```

**Βήμα 2: Αίτηση Certificate**
```bash
sudo certbot certonly --webroot \
  -w /var/www/certbot \
  -d ai-geotee.cloud \
  --email your-email@example.com \
  --agree-tos \
  --no-eff-email
```

**Βήμα 3: Αντιγραφή certificates** (ίδια με πάνω)

---

### Auto-Renewal Setup (Σημαντικό!)

**Δημιουργία auto-renewal cron job:**

```bash
sudo crontab -e
```

**Πρόσθεσε αυτή τη γραμμή:**
```
0 3 * * * certbot renew --quiet && cp /etc/letsencrypt/live/ai-geotee.cloud/*.pem /opt/geotee-chatbot/deployment/ssl/ && docker-compose -f /opt/geotee-chatbot/deployment/docker/docker-compose.yml restart nginx
```

Αυτό θα ελέγχει για renewal κάθε μέρα στις 3 π.μ.

---

## ⚙️ Nginx Configuration Steps {#nginx-steps}

### Βήμα 1: Enable HTTPS στο nginx.conf

**Επεξεργασία του nginx.conf:**

```bash
nano /opt/geotee-chatbot/deployment/nginx/nginx.conf
```

**Στο HTTP server block (port 80), άλλαξε:**

```nginx
# ΠΡΙΝ (temporary access):
location / {
    root /usr/share/nginx/html;
    index index.html;
    try_files $uri $uri/ =404;
}

# ΜΕΤΑ (redirect to HTTPS):
location / {
    return 301 https://$server_name$request_uri;
}
```

**Αφαίρεσε/σχολίασε** την temporary chatbot endpoint location.

**Βήμα 2: Βεβαιώσου ότι το HTTPS server block είναι ενεργό**

Το block που ξεκινάει με:
```nginx
server {
    listen 443 ssl http2;
    ...
}
```

Πρέπει να είναι uncommented και active.

**Βήμα 3: Test Nginx configuration**

```bash
docker exec geotee_nginx nginx -t
```

Πρέπει να δεις:
```
nginx: configuration file /etc/nginx/nginx.conf test is successful
```

**Βήμα 4: Reload Nginx**

```bash
docker-compose restart nginx
```

---

## 🧪 Testing & Verification {#testing}

### 1️⃣ SSL Test

```bash
# Από local machine
curl -I https://ai-geotee.cloud/health
```

Πρέπει να δεις:
```
HTTP/2 200
server: nginx
content-type: text/plain
...
```

### 2️⃣ HTTP → HTTPS Redirect Test

```bash
curl -I http://ai-geotee.cloud/health
```

Πρέπει να δεις:
```
HTTP/1.1 301 Moved Permanently
Location: https://ai-geotee.cloud/health
```

### 3️⃣ Chatbot Endpoint Test

```bash
curl -X POST https://ai-geotee.cloud/webhooks/rest/webhook \
  -H "Content-Type: application/json" \
  -d '{"sender": "test_user", "message": "γεια σου"}'
```

Πρέπει να πάρεις JSON response από το Rasa.

### 4️⃣ Analytics Dashboard Test

Άνοιξε browser:
```
https://ai-geotee.cloud/analytics
```

Πρέπει να σε ζητήσει login:
- **Username:** geotee
- **Password:** An@lyt!c$

### 5️⃣ SSL Certificate Info

```bash
echo | openssl s_client -servername ai-geotee.cloud -connect ai-geotee.cloud:443 2>/dev/null | openssl x509 -noout -dates
```

Πρέπει να δεις:
```
notBefore=Oct 26 10:00:00 2024 GMT
notAfter=Jan 24 10:00:00 2025 GMT
```

### 6️⃣ SSL Labs Test

Επισκέψου:
```
https://www.ssllabs.com/ssltest/analyze.html?d=ai-geotee.cloud
```

Στόχος: **A+ rating**

---

## 🔥 Troubleshooting

### Πρόβλημα: "Connection refused"

```bash
# Έλεγχος αν τρέχει το Nginx
docker ps | grep nginx

# Αν δεν τρέχει
docker-compose up -d nginx

# Logs
docker logs geotee_nginx
```

### Πρόβλημα: "Certificate not found"

```bash
# Έλεγχος αν υπάρχουν τα certificates
ls -la /opt/geotee-chatbot/deployment/ssl/

# Αν λείπουν, αντίγραψέ τα από Let's Encrypt
sudo cp /etc/letsencrypt/live/ai-geotee.cloud/*.pem \
       /opt/geotee-chatbot/deployment/ssl/
```

### Πρόβλημα: "DNS_PROBE_FINISHED_NXDOMAIN"

```bash
# Το DNS δεν έχει γίνει propagate ακόμα
# Περίμενε 1-2 ώρες και ξανά-δοκίμασε

# Ή χρησιμοποίησε προσωρινά το IP
curl http://72.61.179.204/health
```

### Πρόβλημα: Mixed Content (HTTP + HTTPS)

Βεβαιώσου ότι στο chatbot widget:
```javascript
// ✅ Σωστό
const API_URL = 'https://ai-geotee.cloud';

// ❌ Λάθος
const API_URL = 'http://ai-geotee.cloud';
```

---

## 📋 Checklist

- [ ] DNS δείχνει στο 72.61.179.204
- [ ] Let's Encrypt certificate δημιουργήθηκε
- [ ] Certificates αντιγράφηκαν στο /deployment/ssl/
- [ ] nginx.conf updated για HTTPS
- [ ] HTTP redirect σε HTTPS λειτουργεί
- [ ] https://ai-geotee.cloud/health returns 200
- [ ] Chatbot endpoint δουλεύει με HTTPS
- [ ] Analytics dashboard προστατεύεται με password
- [ ] Auto-renewal cron job ρυθμίστηκε
- [ ] SSL Labs test: A+ rating

---

## 🎉 Success!

Αν όλα πάνε καλά, το chatbot θα είναι διαθέσιμο στο:

```
🌐 https://ai-geotee.cloud
📊 https://ai-geotee.cloud/analytics (geotee / An@lyt!c$)
🔌 https://ai-geotee.cloud/webhooks/rest/webhook
```

---

**Έκδοση:** 1.0  
**Τελευταία Ενημέρωση:** Οκτώβριος 2024
