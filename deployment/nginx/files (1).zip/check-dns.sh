#!/bin/bash

# DNS Check Script για ai-geotee.cloud
# Ελέγχει αν το domain δείχνει στο σωστό IP

DOMAIN="ai-geotee.cloud"
EXPECTED_IP="72.61.179.204"

echo "🔍 Έλεγχος DNS για $DOMAIN..."
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# Check DNS resolution
echo "📡 Resolving domain..."
RESOLVED_IP=$(dig +short $DOMAIN A | tail -n1)

if [ -z "$RESOLVED_IP" ]; then
    echo "❌ ΣΦΑΛΜΑ: Το domain δεν επιλύεται σε IP"
    echo ""
    echo "💡 Ενέργειες:"
    echo "   1. Πήγαινε στο Hostinger hPanel → Domains"
    echo "   2. Διάλεξε το domain: $DOMAIN"
    echo "   3. Πρόσθεσε A Record:"
    echo "      Type: A"
    echo "      Name: @"
    echo "      Points to: $EXPECTED_IP"
    echo "      TTL: 3600"
    echo ""
    exit 1
fi

echo "✅ Domain resolved to: $RESOLVED_IP"
echo ""

# Check if IP matches
if [ "$RESOLVED_IP" = "$EXPECTED_IP" ]; then
    echo "✅ ΕΠΙΤΥΧΙΑ! Το DNS είναι σωστά ρυθμισμένο!"
    echo ""
    echo "🎉 Το $DOMAIN δείχνει στο $EXPECTED_IP"
    echo ""
    echo "📋 Επόμενα βήματα:"
    echo "   1. Περίμενε 5-10 λεπτά για DNS propagation"
    echo "   2. Τρέξε: ./ssl-setup.sh"
    echo "   3. Ή δες: DNS_SSL_SETUP_GUIDE.md"
    echo ""
    exit 0
else
    echo "⚠️  ΠΡΟΣΟΧΗ: Το DNS δείχνει σε λάθος IP!"
    echo ""
    echo "   Βρέθηκε:   $RESOLVED_IP"
    echo "   Αναμενόμενο: $EXPECTED_IP"
    echo ""
    echo "💡 Διόρθωση:"
    echo "   1. Πήγαινε στο Hostinger hPanel → Domains"
    echo "   2. Επεξεργασία A Record για $DOMAIN"
    echo "   3. Άλλαξε το Points to σε: $EXPECTED_IP"
    echo "   4. Περίμενε 15-30 λεπτά και ξανά-τρέξε αυτό το script"
    echo ""
    exit 1
fi
